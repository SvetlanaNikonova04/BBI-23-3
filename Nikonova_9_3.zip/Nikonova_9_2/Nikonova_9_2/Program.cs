﻿using lab_9.Serializers;

public abstract class Person
{
    protected string _firstName;
    protected string _lastName;
    public string FirstName { get { return _firstName; } set { _firstName = value; } }
    public string LastName { get { return _lastName; } set { _lastName = value; } }
    public Person() { }
    public Person(string firstName, string lastName)
    {
        _firstName = firstName;
        _lastName = lastName;
    }

    public abstract void Print();
}

public class Student : Person
{
    private double _averageScore;
    private int _studentId;
    public double AvarageScore { get { return _averageScore; } set { _averageScore = value; } }
    public int StudentId { get { return _studentId; } set { _studentId = value; } }
    public Student() { }
    public Student(string firstName, string lastName, double averageScore, int studentId) : base(firstName, lastName)
    {
        _averageScore = averageScore;
        _studentId = studentId;
    }

    public override void Print()
    {
        Console.WriteLine($"{_firstName} {_lastName}: {_averageScore}, {_studentId}");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        List<Student> people = new List<Student>()
        {
            new Student("Иван", "Иванов", 4.5, 12345),
            new Student("Петр", "Петров", 3.8, 54321),
            new Student("Мария", "Сидорова", 4.2, 23456),
            new Student("Ольга", "Кузнецова", 4.0, 34567),
            new Student("Сергей", "Соколов", 4.5, 45678)
        };

        Console.WriteLine("|{0,-15}|{1,-15}|{2,-10}|", "ФИО", "№ студ. билета", "Средний балл");
        Console.WriteLine("--------------------------------------------");
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string dirName = "Lab_9_2";
        path = Path.Combine(path, dirName);
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        MySer serializer = new MyJsonSerilazer();
        string[] files = 
        {
                "Student.json",
        };
        if (!File.Exists(Path.Combine(path, files[0])))
        {
            serializer.Write(people, Path.Combine(path, files[0]));
        }
        var Students1 = serializer.Read<List<Student>>(Path.Combine(path, files[0]));
        foreach (var st in Students1) { st.Print(); }
        Console.WriteLine();
    }
}