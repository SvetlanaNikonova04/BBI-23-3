﻿
struct Struct1
{
    private string _famile;
    private double[] _x;
    public double _sred { get; private set; }
    public Struct1(string famile1, double[] x1)
    {
        _sred = 0;
        _famile = famile1;
        _x = x1;
        for (int i = 0; i < 4; i++)
            _sred += _x[i];
        _sred /= 4;// sred = sred/4
    }
    public void Print()
    {
        Console.WriteLine($"{_famile} {_sred}");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Struct1[] cl = new Struct1[3]
        {
            new Struct1 ("Иванов", new double[] { 3.0, 5.0, 2.0, 3.0 }),
            new Struct1 ("Петров",new double[] { 5.0, 4.0, 5.0, 3.0 }),
            new Struct1 ("Сидоров",new double[] { 5.0, 4.0, 5.0, 5.0 })
        };
        for (int i = 0; i < cl.Length; i++)
        {
            cl[i].Print();
        }

        Max(cl);
        Console.WriteLine();
        for (int i = 0; i < cl.Length; i++)
        {
            if (cl[i]._sred >= 4)
            {
                cl[i].Print();
            }

        }
        void Max(Struct1[] cl)
        {
            for (int i = 0; i < cl.Length - 1; i++)
            {
                double amax = cl[i]._sred;
                int imax = i;
                for (int j = i + 1; j < cl.Length; j++)
                {
                    if (cl[j]._sred > amax)
                    {
                        amax = cl[j]._sred;
                        imax = j;

                    }

                }
                Struct1 temp;
                temp = cl[imax];
                cl[imax] = cl[i];
                cl[i] = temp;

            }
        }
    }
}